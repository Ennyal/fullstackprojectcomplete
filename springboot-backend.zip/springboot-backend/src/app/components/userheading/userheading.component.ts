import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userheading',
  templateUrl: './userheading.component.html',
  styleUrls: ['./userheading.component.css']
})
export class UserheadingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
