export class student
{
  public std_id?:number;
  public std_name?:string;
  public std_Class?:number;
  public std_Address?:string;
  public Phone_no?:string;
  public std_fees?:number
  static std_id: any;
  //public std_fees?:any;
  public phone_no?:any;
}
